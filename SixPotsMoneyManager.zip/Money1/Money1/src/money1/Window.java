package money1;

public class Window {
    
    public SigninPanel signinPanel = new SigninPanel();
    public Main main = new Main();
    public ShowInformationsPanel showInformationsPanel = new ShowInformationsPanel();
    public FillInformatiionsPanel fillInformatiionsPanel = new FillInformatiionsPanel();
    public FillPaymentPanel fillPaymentPanel = new FillPaymentPanel();
    public HistoryPanel historyPanel = new HistoryPanel();
}
