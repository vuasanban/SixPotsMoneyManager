package money1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.time.LocalDate;
import java.time.*;
import java.time.format.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author DELL
 */
public class HistoryPanel extends javax.swing.JPanel {
    public Reader reader = null;
    public BufferedReader bufferedReader = null;
    public Writer writer = null;
    public FileInputStream fileInputStream = null;
    public FileOutputStream fileOutputStream = null;
    
    public HistoryPanel() {
        initComponents();
    }
    
    public ArrayList<JLabel> listLabels = new ArrayList<JLabel>();
    public ArrayList<String> listMoney = new ArrayList<String>();
    public ArrayList<String> listLocalDates = new ArrayList<String>();
    
    public ArrayList<String> potNameList = new ArrayList<String>();
    public ArrayList<String> potMoneyList = new ArrayList<String>();
    public ArrayList<String> potTimeList = new ArrayList<String>();
    
    public void saveHistory(String s){
        /*
        s co dang
        Name\n
        Money\n
        Date\n
        */
        try {
            fileInputStream = new FileInputStream("History.txt");
            reader = new InputStreamReader(fileInputStream, "utf8");
            bufferedReader = new BufferedReader(reader);
            
            int i = -1;
            String line;
            String store = "";
            store = s + store;
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                store = store + line + "\n";
                if (i == 14) break;
            }
            fileOutputStream = new FileOutputStream("History.txt");
            writer = new OutputStreamWriter(fileOutputStream, "utf8");
            writer.write(store);
            
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (writer != null){
                try {
                    if (reader != null){
                        reader.close();
                    }
                    if (bufferedReader != null){
                        bufferedReader.close();
                    }
                    if (writer != null){
                        writer.close();
                    }
                    if (fileInputStream != null){
                        fileInputStream.close();
                    }
                    if (fileOutputStream != null){
                        fileOutputStream.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    public void uploadPotList(){
        try {
            fileInputStream = new FileInputStream("History.txt");
            reader = new InputStreamReader(fileInputStream, "utf8");
            bufferedReader = new BufferedReader(reader);
            
            int i = -1;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                int mod = i%3;
                if (mod == 0) potNameList.add(line);
                else if (mod == 1) potMoneyList.add(line);
                else if (mod == 2) potTimeList.add(line);
            }
            
            while (potNameList.size() != 6){
                potNameList.remove(0);
            }
            
            while (potMoneyList.size() != 6){
                potMoneyList.remove(0);
            }
            
            while (potTimeList.size() != 6){
                potTimeList.remove(0);
            }
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (reader != null){
                    reader.close();
                }
                if (bufferedReader != null){
                    bufferedReader.close();
                }
                if (fileInputStream != null){
                    fileInputStream.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public Icon findIcon(String s){
        
        if (s.equals("Thiết yếu")){
            return MainFrame.window.fillPaymentPanel.getNecessaryJar().getIcon();
        }
        else if (s.equals("Giáo dục")){
            return MainFrame.window.fillPaymentPanel.getEducationJar().getIcon();
        }
        else if (s.equals("Tiết kiệm")){
            return MainFrame.window.fillPaymentPanel.getSavingJar().getIcon();
        }
        else if (s.equals("Hưởng thụ")){
            return MainFrame.window.fillPaymentPanel.getEnjoyJar().getIcon();
        }
        else if (s.equals("Đầu tư")){
            return MainFrame.window.fillPaymentPanel.getInvestmentJar().getIcon();
        }
        else if (s.equals("Thiện nguyện")){
            return MainFrame.window.fillPaymentPanel.getEducationJar().getIcon();
        }
        return null;
    }
    
    
    public void showPotList(){
        uploadPotList();
        for (int i = 5; i >= 0; i--){
            if (i == 0){
                firstJarName.setText(potNameList.get(i));
                firstJarName.setIcon(findIcon(potNameList.get(i)));
                firstMoney.setText(potMoneyList.get(i));
                firstDate.setText(potTimeList.get(i));
            }
            else if (i == 1){
                secondJarName.setText(potNameList.get(i));
                secondJarName.setIcon(findIcon(potNameList.get(i)));
                secondMoney.setText(potMoneyList.get(i));
                secondDate.setText(potTimeList.get(i));
            }
            else if (i == 2){
                thirdJarName.setText(potNameList.get(i));
                thirdJarName.setIcon(findIcon(potNameList.get(i)));
                thirdMoney.setText(potMoneyList.get(i));
                thirdDate.setText(potTimeList.get(i));
            }
            else if (i == 3){
                fourthJarName.setText(potNameList.get(i));
                fourthJarName.setIcon(findIcon(potNameList.get(i)));
                fourthMoney.setText(potMoneyList.get(i));
                fourthDate.setText(potTimeList.get(i));
            }
            else if (i == 4){
                fifthJarName.setText(potNameList.get(i));
                fifthJarName.setIcon(findIcon(potNameList.get(i)));
                fifthMoney.setText(potMoneyList.get(i));
                fifthDate.setText(potTimeList.get(i));
            }
            else if (i == 5){
                sixthJarName.setText(potNameList.get(i));
                sixthJarName.setIcon(findIcon(potNameList.get(i)));
                sixthMoney.setText(potMoneyList.get(i));
                sixthDate.setText(potTimeList.get(i));
            }
        }
    }
    
    public void setFirstJarName(javax.swing.JLabel s) {
        firstJarName.setText(s.getText());
        firstJarName.setIcon(s.getIcon());
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        firstHistory = new javax.swing.JPanel();
        firstJarName = new javax.swing.JLabel();
        firstMoney = new javax.swing.JLabel();
        firstDate = new javax.swing.JLabel();
        sixthHistory = new javax.swing.JPanel();
        sixthJarName = new javax.swing.JLabel();
        sixthMoney = new javax.swing.JLabel();
        sixthDate = new javax.swing.JLabel();
        fifthHistory = new javax.swing.JPanel();
        fifthJarName = new javax.swing.JLabel();
        fifthMoney = new javax.swing.JLabel();
        fifthDate = new javax.swing.JLabel();
        fourthHistory = new javax.swing.JPanel();
        fourthJarName = new javax.swing.JLabel();
        fourthMoney = new javax.swing.JLabel();
        fourthDate = new javax.swing.JLabel();
        thirdHistory = new javax.swing.JPanel();
        thirdJarName = new javax.swing.JLabel();
        thirdMoney = new javax.swing.JLabel();
        thirdDate = new javax.swing.JLabel();
        secondHistory = new javax.swing.JPanel();
        secondJarName = new javax.swing.JLabel();
        secondMoney = new javax.swing.JLabel();
        secondDate = new javax.swing.JLabel();

        setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Lịch sử tiêu dùng");

        firstHistory.setBackground(new java.awt.Color(102, 102, 102));

        firstJarName.setBackground(new java.awt.Color(255, 255, 255));
        firstJarName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        firstJarName.setForeground(new java.awt.Color(255, 255, 255));
        firstJarName.setText("Something");

        firstMoney.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        firstMoney.setForeground(new java.awt.Color(255, 255, 255));

        firstDate.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        firstDate.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout firstHistoryLayout = new javax.swing.GroupLayout(firstHistory);
        firstHistory.setLayout(firstHistoryLayout);
        firstHistoryLayout.setHorizontalGroup(
            firstHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(firstHistoryLayout.createSequentialGroup()
                .addComponent(firstJarName, javax.swing.GroupLayout.PREFERRED_SIZE, 511, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(firstHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(firstMoney, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                    .addComponent(firstDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        firstHistoryLayout.setVerticalGroup(
            firstHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(firstJarName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(firstHistoryLayout.createSequentialGroup()
                .addComponent(firstMoney, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(firstDate, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        sixthHistory.setBackground(new java.awt.Color(102, 102, 102));

        sixthJarName.setBackground(new java.awt.Color(255, 255, 255));
        sixthJarName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        sixthJarName.setForeground(new java.awt.Color(255, 255, 255));
        sixthJarName.setText("Something");

        sixthMoney.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        sixthMoney.setForeground(new java.awt.Color(255, 255, 255));

        sixthDate.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        sixthDate.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout sixthHistoryLayout = new javax.swing.GroupLayout(sixthHistory);
        sixthHistory.setLayout(sixthHistoryLayout);
        sixthHistoryLayout.setHorizontalGroup(
            sixthHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sixthHistoryLayout.createSequentialGroup()
                .addComponent(sixthJarName, javax.swing.GroupLayout.PREFERRED_SIZE, 511, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(sixthHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(sixthMoney, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                    .addComponent(sixthDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        sixthHistoryLayout.setVerticalGroup(
            sixthHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sixthJarName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(sixthHistoryLayout.createSequentialGroup()
                .addComponent(sixthMoney, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(sixthDate, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        fifthHistory.setBackground(new java.awt.Color(102, 102, 102));

        fifthJarName.setBackground(new java.awt.Color(255, 255, 255));
        fifthJarName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        fifthJarName.setForeground(new java.awt.Color(255, 255, 255));
        fifthJarName.setText("Something");

        fifthMoney.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        fifthMoney.setForeground(new java.awt.Color(255, 255, 255));

        fifthDate.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        fifthDate.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout fifthHistoryLayout = new javax.swing.GroupLayout(fifthHistory);
        fifthHistory.setLayout(fifthHistoryLayout);
        fifthHistoryLayout.setHorizontalGroup(
            fifthHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fifthHistoryLayout.createSequentialGroup()
                .addComponent(fifthJarName, javax.swing.GroupLayout.PREFERRED_SIZE, 511, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(fifthHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(fifthMoney, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                    .addComponent(fifthDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        fifthHistoryLayout.setVerticalGroup(
            fifthHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fifthHistoryLayout.createSequentialGroup()
                .addComponent(fifthMoney, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(fifthDate, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(fifthJarName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        fourthHistory.setBackground(new java.awt.Color(102, 102, 102));

        fourthJarName.setBackground(new java.awt.Color(255, 255, 255));
        fourthJarName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        fourthJarName.setForeground(new java.awt.Color(255, 255, 255));
        fourthJarName.setText("Something");

        fourthMoney.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        fourthMoney.setForeground(new java.awt.Color(255, 255, 255));

        fourthDate.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        fourthDate.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout fourthHistoryLayout = new javax.swing.GroupLayout(fourthHistory);
        fourthHistory.setLayout(fourthHistoryLayout);
        fourthHistoryLayout.setHorizontalGroup(
            fourthHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fourthHistoryLayout.createSequentialGroup()
                .addComponent(fourthJarName, javax.swing.GroupLayout.PREFERRED_SIZE, 511, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(fourthHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(fourthMoney, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                    .addComponent(fourthDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        fourthHistoryLayout.setVerticalGroup(
            fourthHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(fourthJarName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(fourthHistoryLayout.createSequentialGroup()
                .addComponent(fourthMoney, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(fourthDate, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        thirdHistory.setBackground(new java.awt.Color(102, 102, 102));

        thirdJarName.setBackground(new java.awt.Color(255, 255, 255));
        thirdJarName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        thirdJarName.setForeground(new java.awt.Color(255, 255, 255));
        thirdJarName.setText("Something");

        thirdMoney.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        thirdMoney.setForeground(new java.awt.Color(255, 255, 255));

        thirdDate.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        thirdDate.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout thirdHistoryLayout = new javax.swing.GroupLayout(thirdHistory);
        thirdHistory.setLayout(thirdHistoryLayout);
        thirdHistoryLayout.setHorizontalGroup(
            thirdHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(thirdHistoryLayout.createSequentialGroup()
                .addComponent(thirdJarName, javax.swing.GroupLayout.PREFERRED_SIZE, 511, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(thirdHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(thirdMoney, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                    .addComponent(thirdDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        thirdHistoryLayout.setVerticalGroup(
            thirdHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(thirdJarName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(thirdHistoryLayout.createSequentialGroup()
                .addComponent(thirdMoney, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(thirdDate, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        secondHistory.setBackground(new java.awt.Color(102, 102, 102));

        secondJarName.setBackground(new java.awt.Color(255, 255, 255));
        secondJarName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        secondJarName.setForeground(new java.awt.Color(255, 255, 255));
        secondJarName.setText("Something");

        secondMoney.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        secondMoney.setForeground(new java.awt.Color(255, 255, 255));

        secondDate.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        secondDate.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout secondHistoryLayout = new javax.swing.GroupLayout(secondHistory);
        secondHistory.setLayout(secondHistoryLayout);
        secondHistoryLayout.setHorizontalGroup(
            secondHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(secondHistoryLayout.createSequentialGroup()
                .addComponent(secondJarName, javax.swing.GroupLayout.PREFERRED_SIZE, 511, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(secondHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(secondMoney, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                    .addComponent(secondDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        secondHistoryLayout.setVerticalGroup(
            secondHistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(secondJarName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(secondHistoryLayout.createSequentialGroup()
                .addComponent(secondMoney, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(secondDate, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(265, 273, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(250, 250, 250))
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(firstHistory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sixthHistory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fifthHistory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fourthHistory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(thirdHistory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(secondHistory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(firstHistory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(secondHistory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(thirdHistory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(fourthHistory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(fifthHistory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(sixthHistory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel fifthDate;
    private javax.swing.JPanel fifthHistory;
    private javax.swing.JLabel fifthJarName;
    private javax.swing.JLabel fifthMoney;
    private javax.swing.JLabel firstDate;
    private javax.swing.JPanel firstHistory;
    private javax.swing.JLabel firstJarName;
    private javax.swing.JLabel firstMoney;
    private javax.swing.JLabel fourthDate;
    private javax.swing.JPanel fourthHistory;
    private javax.swing.JLabel fourthJarName;
    private javax.swing.JLabel fourthMoney;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel secondDate;
    private javax.swing.JPanel secondHistory;
    private javax.swing.JLabel secondJarName;
    private javax.swing.JLabel secondMoney;
    private javax.swing.JLabel sixthDate;
    private javax.swing.JPanel sixthHistory;
    private javax.swing.JLabel sixthJarName;
    private javax.swing.JLabel sixthMoney;
    private javax.swing.JLabel thirdDate;
    private javax.swing.JPanel thirdHistory;
    private javax.swing.JLabel thirdJarName;
    private javax.swing.JLabel thirdMoney;
    // End of variables declaration//GEN-END:variables
}
