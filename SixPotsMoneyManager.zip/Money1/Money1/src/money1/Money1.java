

package money1;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.plaf.synth.SynthLookAndFeel;

public class Money1 {


    public static void main(String[] args) throws IOException{
        try {
        // Set system looks and feel
        UIManager.setLookAndFeel (UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Money1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(Money1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(Money1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(Money1.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        File f = new File("MainData.txt");
        if (!f.isFile()){
            System.out.println("Tao file MainData");
            f.createNewFile();
            FileWriter writer = new FileWriter("MainData.txt");
            String s = "0\n0\n0";
            writer.write(s);
            writer.close();
        }
        
        File f1 = new File ("SixPots.txt");
        if (!f1.isFile()){
            System.out.println("Tao file SixPots");
            f1.createNewFile();
            FileWriter writer = new FileWriter("SixPots.txt");
            String s = "0\n0\n0\n0\n0\n0";
            writer.write(s);
            writer.close();
        }
        
        File f2 = new File ("History.txt");
        if (!f2.isFile()){
            System.out.println("Tao file History");
            f2.createNewFile();
            FileWriter writer = new FileWriter("History.txt");
            String s = "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None\n" +
                        "None";
            writer.write(s);
            writer.close();
        }
        
        Controller controller = new Controller();
    }
    
}
