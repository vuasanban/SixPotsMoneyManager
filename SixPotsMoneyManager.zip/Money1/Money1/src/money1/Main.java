package money1;

import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;


public class Main extends javax.swing.JPanel {

    
    public Main() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        leftPanel = new javax.swing.JPanel();
        menuPanel = new javax.swing.JPanel();
        menuLabel = new javax.swing.JLabel();
        newDataButton = new javax.swing.JButton();
        paymentButton = new javax.swing.JButton();
        historyButton = new javax.swing.JButton();
        mainScreen = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(300, 450));

        leftPanel.setBackground(new java.awt.Color(102, 102, 102));
        leftPanel.setPreferredSize(new java.awt.Dimension(300, 450));

        menuPanel.setBackground(new java.awt.Color(0, 162, 232));

        menuLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        menuLabel.setForeground(new java.awt.Color(255, 255, 255));
        menuLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        menuLabel.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\white-menu.png")); // NOI18N
        menuLabel.setText("MENU");

        javax.swing.GroupLayout menuPanelLayout = new javax.swing.GroupLayout(menuPanel);
        menuPanel.setLayout(menuPanelLayout);
        menuPanelLayout.setHorizontalGroup(
            menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menuLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        menuPanelLayout.setVerticalGroup(
            menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menuLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 67, Short.MAX_VALUE)
        );

        newDataButton.setBackground(new java.awt.Color(153, 217, 234));
        newDataButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        newDataButton.setForeground(new java.awt.Color(255, 255, 255));
        newDataButton.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\white-new.png")); // NOI18N
        newDataButton.setText("Tạo mới dữ liệu");
        newDataButton.setBorder(null);
        newDataButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                newDataButtonMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                newDataButtonMouseReleased(evt);
            }
        });
        newDataButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newDataButtonActionPerformed(evt);
            }
        });

        paymentButton.setBackground(new java.awt.Color(153, 217, 234));
        paymentButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        paymentButton.setForeground(new java.awt.Color(255, 255, 255));
        paymentButton.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\pay.png")); // NOI18N
        paymentButton.setText("Nhập chi tiêu ");
        paymentButton.setBorder(null);
        paymentButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                paymentButtonMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                paymentButtonMouseReleased(evt);
            }
        });
        paymentButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paymentButtonActionPerformed(evt);
            }
        });

        historyButton.setBackground(new java.awt.Color(153, 217, 234));
        historyButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        historyButton.setForeground(new java.awt.Color(255, 255, 255));
        historyButton.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\white-history.png")); // NOI18N
        historyButton.setText("Lịch sử chi tiêu");
        historyButton.setBorder(null);
        historyButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                historyButtonMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                historyButtonMouseReleased(evt);
            }
        });
        historyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                historyButtonActionPerformed(evt);
            }
        });

        mainScreen.setBackground(new java.awt.Color(153, 217, 234));
        mainScreen.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        mainScreen.setForeground(new java.awt.Color(255, 255, 255));
        mainScreen.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\white-main-screen.png")); // NOI18N
        mainScreen.setText("Màn hình chính");
        mainScreen.setBorder(null);
        mainScreen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                mainScreenMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                mainScreenMouseReleased(evt);
            }
        });
        mainScreen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mainScreenActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout leftPanelLayout = new javax.swing.GroupLayout(leftPanel);
        leftPanel.setLayout(leftPanelLayout);
        leftPanelLayout.setHorizontalGroup(
            leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menuPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(leftPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(newDataButton, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                    .addComponent(paymentButton, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                    .addComponent(historyButton, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                    .addComponent(mainScreen, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE))
                .addContainerGap())
        );
        leftPanelLayout.setVerticalGroup(
            leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftPanelLayout.createSequentialGroup()
                .addComponent(menuPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(newDataButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(paymentButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(historyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(mainScreen, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 131, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(leftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(leftPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void newDataButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newDataButtonActionPerformed

        MainFrame.window.fillInformatiionsPanel.setVisible(true);
        MainFrame.window.showInformationsPanel.setVisible(false);
        MainFrame.window.fillPaymentPanel.setVisible(false);
        MainFrame.window.historyPanel.setVisible(false);
    }//GEN-LAST:event_newDataButtonActionPerformed

    private void paymentButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paymentButtonActionPerformed
        MainFrame.window.fillPaymentPanel.setVisible(true);
        MainFrame.window.showInformationsPanel.setVisible(false);
        MainFrame.window.fillInformatiionsPanel.setVisible(false);
        MainFrame.window.historyPanel.setVisible(false);
    }//GEN-LAST:event_paymentButtonActionPerformed

    private void historyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_historyButtonActionPerformed
        MainFrame.window.historyPanel.setVisible(true);
        MainFrame.window.fillPaymentPanel.setVisible(false);
        MainFrame.window.showInformationsPanel.setVisible(false);
        MainFrame.window.fillPaymentPanel.setVisible(false);
        
        MainFrame.window.historyPanel.showPotList();
    }//GEN-LAST:event_historyButtonActionPerformed

    private void mainScreenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mainScreenActionPerformed
        MainFrame.window.showInformationsPanel.setVisible(true);
        MainFrame.window.historyPanel.setVisible(false);
        MainFrame.window.fillPaymentPanel.setVisible(false);
        MainFrame.window.fillPaymentPanel.setVisible(false);
    }//GEN-LAST:event_mainScreenActionPerformed

    private void newDataButtonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_newDataButtonMousePressed
        newDataButton.setBackground(new Color(83, 191, 220));
    }//GEN-LAST:event_newDataButtonMousePressed

    private void newDataButtonMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_newDataButtonMouseReleased
        newDataButton.setBackground(new Color(153, 217, 234));
    }//GEN-LAST:event_newDataButtonMouseReleased

    private void paymentButtonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paymentButtonMousePressed
        paymentButton.setBackground(new Color(83, 191, 220));
    }//GEN-LAST:event_paymentButtonMousePressed

    private void paymentButtonMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paymentButtonMouseReleased
        paymentButton.setBackground(new Color(153, 217, 234));
    }//GEN-LAST:event_paymentButtonMouseReleased

    private void historyButtonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_historyButtonMousePressed
        historyButton.setBackground(new Color(83, 191, 220));
    }//GEN-LAST:event_historyButtonMousePressed

    private void historyButtonMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_historyButtonMouseReleased
        historyButton.setBackground(new Color(153, 217, 234));
    }//GEN-LAST:event_historyButtonMouseReleased

    private void mainScreenMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainScreenMousePressed
        mainScreen.setBackground(new Color(83, 191, 220));
    }//GEN-LAST:event_mainScreenMousePressed

    private void mainScreenMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainScreenMouseReleased
        mainScreen.setBackground(new Color(153, 217, 234));
    }//GEN-LAST:event_mainScreenMouseReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton historyButton;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JButton mainScreen;
    private javax.swing.JLabel menuLabel;
    private javax.swing.JPanel menuPanel;
    private javax.swing.JButton newDataButton;
    private javax.swing.JButton paymentButton;
    // End of variables declaration//GEN-END:variables
}
