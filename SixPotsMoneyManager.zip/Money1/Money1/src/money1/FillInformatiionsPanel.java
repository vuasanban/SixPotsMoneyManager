package money1;

import java.io.FileReader;
import java.io.FileWriter;
import java.util.logging.*;
import javax.swing.JOptionPane;

public class FillInformatiionsPanel extends javax.swing.JPanel {

    // Dumbshit I'm gonna make here
    public FileReader reader = null;  
    public FileWriter writer = null;
    //
    
    
    public FillInformatiionsPanel() {
        initComponents();   
    }

    public String getCurrency() {
        return currency;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        currencyComboBox = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        moneyAllTextField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        necessaryPercentageTextField = new javax.swing.JTextField();
        educationPercentageTextField = new javax.swing.JTextField();
        savingPercentageTextField = new javax.swing.JTextField();
        enjoyPercentageTextField = new javax.swing.JTextField();
        investmentPercentageTextField = new javax.swing.JTextField();
        charityPercentageTextField = new javax.swing.JTextField();
        submitButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();

        setBackground(new java.awt.Color(204, 204, 204));

        currencyComboBox.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        currencyComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "VND", "USD" }));
        currencyComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                currencyComboBoxActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel1.setText("Chọn đơn vị tiền tệ");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel2.setText("Nhập số lượng tiền");

        moneyAllTextField.setBorder(null);
        moneyAllTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moneyAllTextFieldActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel3.setText("Nhập tỉ lệ");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\necessary.png")); // NOI18N
        jLabel4.setText("Thiết yếu");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel5.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\education.png")); // NOI18N
        jLabel5.setText("Giáo dục");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\saving.png")); // NOI18N
        jLabel6.setText("Tiết kiệm");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\enjoy.png")); // NOI18N
        jLabel7.setText("Hưởng thụ");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\investment.png")); // NOI18N
        jLabel8.setText("Đầu tư");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\charity.png")); // NOI18N
        jLabel9.setText("Thiện nguyện");

        necessaryPercentageTextField.setBorder(null);

        educationPercentageTextField.setBorder(null);

        savingPercentageTextField.setBorder(null);

        enjoyPercentageTextField.setBorder(null);

        investmentPercentageTextField.setBorder(null);

        charityPercentageTextField.setBorder(null);

        submitButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        submitButton.setText("Submit");
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });

        cancelButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(currencyComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(68, 68, 68))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(277, 277, 277)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(moneyAllTextField)
                            .addComponent(enjoyPercentageTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
                            .addComponent(investmentPercentageTextField)
                            .addComponent(charityPercentageTextField)
                            .addComponent(educationPercentageTextField, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(savingPercentageTextField, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(necessaryPercentageTextField, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addGap(33, 33, 33))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(316, 316, 316))
            .addGroup(layout.createSequentialGroup()
                .addGap(215, 215, 215)
                .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(118, 118, 118)
                .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(currencyComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(moneyAllTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(necessaryPercentageTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(educationPercentageTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(savingPercentageTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(enjoyPercentageTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(investmentPercentageTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(charityPercentageTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitButton)
                    .addComponent(cancelButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void moneyAllTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moneyAllTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_moneyAllTextFieldActionPerformed

    public String getCalculatedText(String percentage) {
        long per = Long.parseLong(percentage);
        long value = Long.parseLong(moneyAllTextField.getText());
        long result = per*value/100;
        String tmp = String.valueOf(result);
        
        return tmp;
    }
    
    public boolean isNumeric(String num){
        if (num == null){
            return false;
        }
        try {
            double d = Double.parseDouble(num);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }
    
    public boolean handleExceptions() {
        if (!isNumeric(moneyAllTextField.getText())){
            JOptionPane.showMessageDialog(this, "Bạn nhập sai định dạng ở ô Nhập số lượng tiền");
            return false;
        }
        if (moneyAllTextField.getText().isBlank()){
            JOptionPane.showMessageDialog(this, "Bạn đang bỏ trống ô Nhập số lượng tiền");
            return false;
        }
        if (Long.parseLong(moneyAllTextField.getText()) < 0){
            JOptionPane.showMessageDialog(this, "Tổng lượng tiền phải lớn hơn hoặc bằng 0");
            return false;
        }
        if (!isNumeric(necessaryPercentageTextField.getText()) || Long.parseLong(necessaryPercentageTextField.getText()) > 100 || Long.parseLong(necessaryPercentageTextField.getText()) <= 0){
            JOptionPane.showMessageDialog(this, "Bạn nhập sai định dạng ô Thiết yếu (Phải > 0 và <= 100)");
            return false;
        }
        if (necessaryPercentageTextField.getText().isBlank()){
            JOptionPane.showMessageDialog(this, "Bạn đang bỏ trống ô Thiết yếu");
            return false;
        }
        if (!isNumeric(educationPercentageTextField.getText()) || Long.parseLong(educationPercentageTextField.getText()) > 100 || Long.parseLong(educationPercentageTextField.getText()) <= 0){
            JOptionPane.showMessageDialog(this, "Bạn nhập sai định dạng ô Giáo dục (Phải > 0 và <= 100)");
            return false;
        }
        if (educationPercentageTextField.getText().isBlank()){
            JOptionPane.showMessageDialog(this, "Bạn đang bỏ trống ô Giáo dục");
            return false;
        }
        if (!isNumeric(savingPercentageTextField.getText()) || Long.parseLong(savingPercentageTextField.getText()) > 100 || Long.parseLong(savingPercentageTextField.getText()) <= 0){
            JOptionPane.showMessageDialog(this, "Bạn nhập sai định dạng ô Tiết kiệm (Phải > 0 và <= 100)");
            return false;
        }
        if (savingPercentageTextField.getText().isBlank()){
            JOptionPane.showMessageDialog(this, "Bạn đang bỏ trống ô Tiết kiệm");
            return false;
        }
        if (!isNumeric(enjoyPercentageTextField.getText()) || Long.parseLong(enjoyPercentageTextField.getText()) > 100 || Long.parseLong(enjoyPercentageTextField.getText()) <= 0){
            JOptionPane.showMessageDialog(this, "Bạn nhập sai định dạng ô Hưởng thụ (Phải > 0 và <= 100)");
            return false;
        }
        if (enjoyPercentageTextField.getText().isBlank()){
            JOptionPane.showMessageDialog(this, "Bạn đang bỏ trống ô Hưởng thụ");
            return false;
        }
        if (!isNumeric(investmentPercentageTextField.getText()) || Long.parseLong(investmentPercentageTextField.getText()) > 100 || Long.parseLong(investmentPercentageTextField.getText()) <= 0){
            JOptionPane.showMessageDialog(this, "Bạn nhập sai định dạng ô Đầu tư (Phải > 0 và <= 100)");
            return false;
        }
        if (investmentPercentageTextField.getText().isBlank()){
            JOptionPane.showMessageDialog(this, "Bạn đang bỏ trống ô Đầu tư");
            return false;
        }
        if (!isNumeric(charityPercentageTextField.getText()) || Long.parseLong(charityPercentageTextField.getText()) > 100 || Long.parseLong(charityPercentageTextField.getText()) <= 0){
            JOptionPane.showMessageDialog(this, "Bạn nhập sai định dạng ô Thiện nguyện (Phải > 0 và <= 100)");
            return false;
        }
        if (charityPercentageTextField.getText().isBlank()){
            JOptionPane.showMessageDialog(this, "Bạn đang bỏ trống ô Thiện nguyện");
            return false;
        }
        if (Long.parseLong(necessaryPercentageTextField.getText())
           +Long.parseLong(educationPercentageTextField.getText())
           +Long.parseLong(savingPercentageTextField.getText())
           +Long.parseLong(enjoyPercentageTextField.getText())
           +Long.parseLong(investmentPercentageTextField.getText())
           +Long.parseLong(charityPercentageTextField.getText())!= 100){
            JOptionPane.showMessageDialog(this, "Tổng tỉ lệ các hũ không bằng 100, vui lòng nhập lại");
            return false;
        }
        return true;
    }
    
    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed

//        MainFrame.window.showInformationsPanel.setTextNecessaryLabel(getCalculatedText(necessaryPercentageTextField.getText()));
//        MainFrame.window.showInformationsPanel.setTextEducationLabel(getCalculatedText(educationPercentageTextField.getText()));
//        MainFrame.window.showInformationsPanel.setTextSavingLabel(getCalculatedText(savingPercentageTextField.getText()));
//        MainFrame.window.showInformationsPanel.setTextEnjoyLabel(getCalculatedText(enjoyPercentageTextField.getText()));
//        MainFrame.window.showInformationsPanel.setTextInvestmentLabel(getCalculatedText(investmentPercentageTextField.getText()));
//        MainFrame.window.showInformationsPanel.setTextCharityLabel(getCalculatedText(charityPercentageTextField.getText()));
                
        if (handleExceptions()){
            MainFrame.window.fillInformatiionsPanel.setVisible(false);
            MainFrame.window.showInformationsPanel.setVisible(true);
            MainFrame.window.main.setVisible(true);

            //Test area
            MainFrame.window.showInformationsPanel.saveMoneyLeft(moneyAllTextField.getText());
            MainFrame.window.showInformationsPanel.showMoneyLeft();
            MainFrame.window.showInformationsPanel.saveMoneyAll(moneyAllTextField.getText());
            MainFrame.window.showInformationsPanel.showMoneyAll();
            MainFrame.window.showInformationsPanel.saveMoneyNecessary(getCalculatedText(necessaryPercentageTextField.getText()));
            MainFrame.window.showInformationsPanel.showMoneyNecessary();
            MainFrame.window.showInformationsPanel.saveMoneyEducation(getCalculatedText(educationPercentageTextField.getText()));
            MainFrame.window.showInformationsPanel.showMoneyEducation();
            MainFrame.window.showInformationsPanel.saveMoneySaving(getCalculatedText(savingPercentageTextField.getText()));
            MainFrame.window.showInformationsPanel.showMoneySaving();
            MainFrame.window.showInformationsPanel.saveMoneyEnjoy(getCalculatedText(enjoyPercentageTextField.getText()));
            MainFrame.window.showInformationsPanel.showMoneyEnjoy();
            MainFrame.window.showInformationsPanel.saveMoneyInvestment(getCalculatedText(investmentPercentageTextField.getText()));
            MainFrame.window.showInformationsPanel.showMoneyInvestment();
            MainFrame.window.showInformationsPanel.saveMoneyCharity(getCalculatedText(charityPercentageTextField.getText()));
            MainFrame.window.showInformationsPanel.showMoneyCharity();
            //
        }
        
    }//GEN-LAST:event_submitButtonActionPerformed

    private void currencyComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_currencyComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_currencyComboBoxActionPerformed

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        MainFrame.window.showInformationsPanel.setVisible(true);
        MainFrame.window.fillInformatiionsPanel.setVisible(false);
    }//GEN-LAST:event_cancelButtonActionPerformed


    
    
    private String currency;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancelButton;
    private javax.swing.JTextField charityPercentageTextField;
    private javax.swing.JComboBox<String> currencyComboBox;
    private javax.swing.JTextField educationPercentageTextField;
    private javax.swing.JTextField enjoyPercentageTextField;
    private javax.swing.JTextField investmentPercentageTextField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField moneyAllTextField;
    private javax.swing.JTextField necessaryPercentageTextField;
    private javax.swing.JTextField savingPercentageTextField;
    private javax.swing.JButton submitButton;
    // End of variables declaration//GEN-END:variables
}
