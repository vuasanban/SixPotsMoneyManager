package money1;

import java.time.*;
import java.time.format.DateTimeFormatter;
import javax.swing.JLabel;

public class FillPaymentPanel extends javax.swing.JPanel {

    public FillPaymentPanel() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        necessaryJar = new javax.swing.JLabel();
        necessaryPayment = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        educationJar = new javax.swing.JLabel();
        educationPayment = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        savingJar = new javax.swing.JLabel();
        savingPayment = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        enjoyJar = new javax.swing.JLabel();
        enjoyPayment = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        investmentJar = new javax.swing.JLabel();
        investmentPayment = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        charityJar = new javax.swing.JLabel();
        charityPayment = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();

        setBackground(new java.awt.Color(0, 0, 0));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Nhập chi tiêu");

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        necessaryJar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        necessaryJar.setForeground(new java.awt.Color(255, 255, 255));
        necessaryJar.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\necessary-payment.png")); // NOI18N
        necessaryJar.setText("Thiết yếu");

        necessaryPayment.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        necessaryPayment.setText("0");
        necessaryPayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                necessaryPaymentActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("VND");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(necessaryPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(necessaryJar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(necessaryJar, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(necessaryPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );

        jPanel2.setBackground(new java.awt.Color(102, 102, 102));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));

        educationJar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        educationJar.setForeground(new java.awt.Color(255, 255, 255));
        educationJar.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\education-payment.png")); // NOI18N
        educationJar.setText("Giáo dục");

        educationPayment.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        educationPayment.setText("0");
        educationPayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                educationPaymentActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("VND");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(educationPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(educationJar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(educationJar, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(educationPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );

        jPanel3.setBackground(new java.awt.Color(102, 102, 102));
        jPanel3.setForeground(new java.awt.Color(255, 255, 255));

        savingJar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        savingJar.setForeground(new java.awt.Color(255, 255, 255));
        savingJar.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\saving-payment.png")); // NOI18N
        savingJar.setText("Tiết kiệm");

        savingPayment.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        savingPayment.setText("0");
        savingPayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savingPaymentActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("VND");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(savingPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(savingJar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(savingJar, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(savingPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );

        jPanel4.setBackground(new java.awt.Color(102, 102, 102));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        enjoyJar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        enjoyJar.setForeground(new java.awt.Color(255, 255, 255));
        enjoyJar.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\enjoy-payment.png")); // NOI18N
        enjoyJar.setText("Hưởng thụ");

        enjoyPayment.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        enjoyPayment.setText("0");
        enjoyPayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enjoyPaymentActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("VND");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(enjoyPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(enjoyJar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(enjoyJar, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(enjoyPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );

        jPanel5.setBackground(new java.awt.Color(102, 102, 102));
        jPanel5.setForeground(new java.awt.Color(255, 255, 255));

        investmentJar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        investmentJar.setForeground(new java.awt.Color(255, 255, 255));
        investmentJar.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\investment-payment.png")); // NOI18N
        investmentJar.setText("Đầu tư");

        investmentPayment.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        investmentPayment.setText("0");
        investmentPayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                investmentPaymentActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("VND");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(investmentPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(investmentJar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(investmentJar, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(investmentPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );

        jPanel6.setBackground(new java.awt.Color(102, 102, 102));
        jPanel6.setForeground(new java.awt.Color(255, 255, 255));

        charityJar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        charityJar.setForeground(new java.awt.Color(255, 255, 255));
        charityJar.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\charity-payment.png")); // NOI18N
        charityJar.setText("Thiện nguyện");

        charityPayment.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        charityPayment.setText("0");
        charityPayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                charityPaymentActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("VND");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(charityPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(charityJar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(charityJar, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(charityPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton1.setText("Submit");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        cancelButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cancelButton.setText("Cancel");
        cancelButton.setBorder(null);
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(240, 240, 240)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53)
                        .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void necessaryPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_necessaryPaymentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_necessaryPaymentActionPerformed

    private void educationPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_educationPaymentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_educationPaymentActionPerformed

    private void savingPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savingPaymentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_savingPaymentActionPerformed

    private void enjoyPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enjoyPaymentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_enjoyPaymentActionPerformed

    private void investmentPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_investmentPaymentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_investmentPaymentActionPerformed

    private void charityPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_charityPaymentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_charityPaymentActionPerformed

    public String getCalculatedPayment(String beforeText, String minusText) {
        long before = Integer.parseInt(beforeText);
        long minus = Integer.parseInt(minusText);
        long after = before - minus;
        
        String tmp = String.valueOf(after);
        return tmp;
    }
    
    public long toLongFast(String s){
        return Long.parseLong(s);
    }
    
    public void resetTextArea() {
        necessaryPayment.setText("0");
        educationPayment.setText("0");
        savingPayment.setText("0");
        enjoyPayment.setText("0");
        investmentPayment.setText("0");
        charityPayment.setText("0");
    }
    
    public void changeShowInfoLabelValue() {
//        MainFrame.window.showInformationsPanel.setTextNecessaryLabel(getCalculatedPayment(MainFrame.window.showInformationsPanel.getTextNecessaryLabel(), necessaryPayment.getText()));
//        MainFrame.window.showInformationsPanel.setTextEducationLabel(getCalculatedPayment(MainFrame.window.showInformationsPanel.getTextEducationLabel(), educationPayment.getText()));
//        MainFrame.window.showInformationsPanel.setTextSavingLabel(getCalculatedPayment(MainFrame.window.showInformationsPanel.getTextSavingLabel(), savingPayment.getText()));
//        MainFrame.window.showInformationsPanel.setTextEnjoyLabel(getCalculatedPayment(MainFrame.window.showInformationsPanel.getTextEnjoyLabel(), enjoyPayment.getText()));
//        MainFrame.window.showInformationsPanel.setTextInvestmentLabel(getCalculatedPayment(MainFrame.window.showInformationsPanel.getTextInvestmentyLabel(), investmentPayment.getText()));
//        MainFrame.window.showInformationsPanel.setTextCharityLabel(getCalculatedPayment(MainFrame.window.showInformationsPanel.getTextCharityLabel(), charityPayment.getText()));
        
        MainFrame.window.showInformationsPanel.saveMoneyNecessary(getCalculatedPayment(MainFrame.window.showInformationsPanel.getTextNecessaryLabel(), necessaryPayment.getText()));
        MainFrame.window.showInformationsPanel.saveMoneyEducation(getCalculatedPayment(MainFrame.window.showInformationsPanel.getTextEducationLabel(), educationPayment.getText()));
        MainFrame.window.showInformationsPanel.saveMoneySaving(getCalculatedPayment(MainFrame.window.showInformationsPanel.getTextSavingLabel(), savingPayment.getText()));
        MainFrame.window.showInformationsPanel.saveMoneyEnjoy(getCalculatedPayment(MainFrame.window.showInformationsPanel.getTextEnjoyLabel(), enjoyPayment.getText()));
        MainFrame.window.showInformationsPanel.saveMoneyInvestment(getCalculatedPayment(MainFrame.window.showInformationsPanel.getTextInvestmentyLabel(), investmentPayment.getText()));
        MainFrame.window.showInformationsPanel.saveMoneyCharity(getCalculatedPayment(MainFrame.window.showInformationsPanel.getTextCharityLabel(), charityPayment.getText()));
        
        MainFrame.window.showInformationsPanel.showSixPots();
        
        long total = toLongFast(necessaryPayment.getText()) + toLongFast(educationPayment.getText()) + toLongFast(savingPayment.getText());
        total += toLongFast(enjoyPayment.getText()) + toLongFast(investmentPayment.getText()) + toLongFast(charityPayment.getText());
        
        MainFrame.window.showInformationsPanel.saveMoneyPay(String.valueOf(total));
        String s = MainFrame.window.showInformationsPanel.getTextMoneyLeftLabel();
        MainFrame.window.showInformationsPanel.saveMoneyLeft(String.valueOf(Integer.parseInt(s) - total));
        
        MainFrame.window.showInformationsPanel.showMainInfo();
    }
    
    public void changeHistory() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
        LocalDateTime time = LocalDateTime.now();
        String timeString = time.format(formatter);
        if (!necessaryPayment.getText().equals("0")){
            String tmp = necessaryJar.getText() + "\n" + necessaryPayment.getText() + "\n" + timeString + "\n";
            MainFrame.window.historyPanel.saveHistory(tmp);
        }
        if (!educationPayment.getText().equals("0")){
            String tmp = educationJar.getText() + "\n" + educationPayment.getText() + "\n" + timeString + "\n";
            MainFrame.window.historyPanel.saveHistory(tmp);
        }
        if (!savingPayment.getText().equals("0")){
            String tmp = savingJar.getText() + "\n" + savingPayment.getText() + "\n" + timeString + "\n";
            MainFrame.window.historyPanel.saveHistory(tmp);
        }
        if (!enjoyPayment.getText().equals("0")){
            String tmp = enjoyJar.getText() + "\n" + enjoyPayment.getText() + "\n" + timeString + "\n";
            MainFrame.window.historyPanel.saveHistory(tmp);
        }
        if (!investmentPayment.getText().equals("0")){
            String tmp = investmentJar.getText() + "\n" + investmentPayment.getText() + "\n" + timeString + "\n";
            MainFrame.window.historyPanel.saveHistory(tmp);
        }
        if (!charityPayment.getText().equals("0")){
            String tmp = charityJar.getText() + "\n" + charityPayment.getText() + "\n" + timeString + "\n";
            MainFrame.window.historyPanel.saveHistory(tmp);
        }
    }

    
    public JLabel getNecessaryJar() {
        return necessaryJar;
    }

    public JLabel getCharityJar() {
        return charityJar;
    }

    public JLabel getEducationJar() {
        return educationJar;
    }

    public JLabel getEnjoyJar() {
        return enjoyJar;
    }

    public JLabel getInvestmentJar() {
        return investmentJar;
    }

    public JLabel getSavingJar() {
        return savingJar;
    }
    
    public boolean isNumeric(String num){
        if (num == null){
            return false;
        }
        try {
            double d = Double.parseDouble(num);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }
    
    public void handleExceptions() {
        if (necessaryPayment.getText().isBlank() || !isNumeric(necessaryPayment.getText())){
            necessaryPayment.setText("0");
        }
        if (educationPayment.getText().isBlank() || !isNumeric(educationPayment.getText())){
            educationPayment.setText("0");
        }
        if (savingPayment.getText().isBlank() || !isNumeric(savingPayment.getText())){
            savingPayment.setText("0");
        }
        if (enjoyPayment.getText().isBlank() || !isNumeric(enjoyPayment.getText())){
            enjoyPayment.setText("0");
        }
        if (investmentPayment.getText().isBlank() || !isNumeric(investmentPayment.getText())){
            investmentPayment.setText("0");
        }
        if (charityPayment.getText().isBlank() || !isNumeric(charityPayment.getText())){
            charityPayment.setText("0");
        }
    }
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        MainFrame.window.fillPaymentPanel.setVisible(false);
        MainFrame.window.showInformationsPanel.setVisible(true);
        
        handleExceptions();
        
        changeShowInfoLabelValue();
        changeHistory();
//        MainFrame.window.historyPanel.showHistory();
//        
        resetTextArea();
        MainFrame.window.historyPanel.showPotList();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        // TODO add your handling code here:
        MainFrame.window.showInformationsPanel.setVisible(true);
        MainFrame.window.fillPaymentPanel.setVisible(false);
        
        resetTextArea();
    }//GEN-LAST:event_cancelButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancelButton;
    private javax.swing.JLabel charityJar;
    private javax.swing.JTextField charityPayment;
    private javax.swing.JLabel educationJar;
    private javax.swing.JTextField educationPayment;
    private javax.swing.JLabel enjoyJar;
    private javax.swing.JTextField enjoyPayment;
    private javax.swing.JLabel investmentJar;
    private javax.swing.JTextField investmentPayment;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JLabel necessaryJar;
    private javax.swing.JTextField necessaryPayment;
    private javax.swing.JLabel savingJar;
    private javax.swing.JTextField savingPayment;
    // End of variables declaration//GEN-END:variables
}
