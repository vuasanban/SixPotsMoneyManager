package money1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UIManager;

public class ShowInformationsPanel extends javax.swing.JPanel {
    // Dumbshit I'm gonna make here
    public FileReader reader = null;  
    public FileWriter writer = null;
    public BufferedReader bufferedReader = null;
    public BufferedWriter bufferedWriter = null;
    //
    
    public ShowInformationsPanel() {
        initComponents();
        
    }
    
    public void showMoneyPay() {
        try {
            reader = new FileReader("MainData.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 1){
                    moneyPayLabel.setText(line);
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (reader != null){
                    reader.close();
                }
                if (bufferedReader != null){
                    bufferedReader.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void saveMoneyPay(String s) {
        try {
            reader = new FileReader("MainData.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            String store = "";
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 1){
                    store += s + "\n";
                }
                else store = store + line + "\n";
            }
            writer = new FileWriter("MainData.txt");
            writer.write(store);
            
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (writer != null){
                try {
                    if (reader != null){
                        reader.close();
                    }
                    if (bufferedReader != null){
                        bufferedReader.close();
                    }
                    if (writer != null){
                        writer.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void showMoneyLeft() {
        try {
            reader = new FileReader("MainData.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 2){
                    moneyLeftLabel.setText(line);
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (reader != null){
                    reader.close();
                }
                if (bufferedReader != null){
                    bufferedReader.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void saveMoneyLeft(String s) {
        try {
            reader = new FileReader("MainData.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            String store = "";
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 2){
                    store += s + "\n";
                }
                else store = store + line + "\n";
            }
            writer = new FileWriter("MainData.txt");
            writer.write(store);
            
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (writer != null){
                try {
                    if (reader != null){
                        reader.close();
                    }
                    if (bufferedReader != null){
                        bufferedReader.close();
                    }
                    if (writer != null){
                        writer.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void showMoneyAll() {
        try {
            reader = new FileReader("MainData.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 3){
                    moneyAllLabel.setText(line);
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (reader != null){
                    reader.close();
                }
                if (bufferedReader != null){
                    bufferedReader.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void saveMoneyAll(String s) {
        try {
            reader = new FileReader("MainData.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            String store = "";
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 3){
                    store += s + "\n";
                }
                else store = store + line + "\n";
            }
            writer = new FileWriter("MainData.txt");
            writer.write(store);
            
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (writer != null){
                try {
                    if (reader != null){
                        reader.close();
                    }
                    if (bufferedReader != null){
                        bufferedReader.close();
                    }
                    if (writer != null){
                        writer.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void showMoneyNecessary () {
        try {
            reader = new FileReader("SixPots.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 1){
                    necessaryLabel.setText(line);
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (reader != null){
                    reader.close();
                }
                if (bufferedReader != null){
                    bufferedReader.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void saveMoneyNecessary(String s) {
        try {
            reader = new FileReader("SixPots.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            String store = "";
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 1){
                    store += s + "\n";
                }
                else store = store + line + "\n";
            }
            writer = new FileWriter("SixPots.txt");
            writer.write(store);
            
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (writer != null){
                try {
                    if (reader != null){
                        reader.close();
                    }
                    if (bufferedReader != null){
                        bufferedReader.close();
                    }
                    if (writer != null){
                        writer.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void showMoneyEducation() {
        try {
            reader = new FileReader("SixPots.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 2){
                    educationLabel.setText(line);
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (reader != null){
                    reader.close();
                }
                if (bufferedReader != null){
                    bufferedReader.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void saveMoneyEducation(String s) {
        try {
            reader = new FileReader("SixPots.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            String store = "";
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 2){
                    store += s + "\n";
                }
                else store = store + line + "\n";
            }
            writer = new FileWriter("SixPots.txt");
            writer.write(store);
            
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (writer != null){
                try {
                    if (reader != null){
                        reader.close();
                    }
                    if (bufferedReader != null){
                        bufferedReader.close();
                    }
                    if (writer != null){
                        writer.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void showMoneySaving () {
        try {
            reader = new FileReader("SixPots.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 3){
                    savingLabel.setText(line);
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (reader != null){
                    reader.close();
                }
                if (bufferedReader != null){
                    bufferedReader.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void saveMoneySaving(String s) {
        try {
            reader = new FileReader("SixPots.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            String store = "";
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 3){
                    store += s + "\n";
                }
                else store = store + line + "\n";
            }
            writer = new FileWriter("SixPots.txt");
            writer.write(store);
            
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (writer != null){
                try {
                    if (reader != null){
                        reader.close();
                    }
                    if (bufferedReader != null){
                        bufferedReader.close();
                    }
                    if (writer != null){
                        writer.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void showMoneyEnjoy () {
        try {
            reader = new FileReader("SixPots.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 4){
                    enjoyLabel.setText(line);
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (reader != null){
                    reader.close();
                }
                if (bufferedReader != null){
                    bufferedReader.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void saveMoneyEnjoy(String s) {
        try {
            reader = new FileReader("SixPots.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            String store = "";
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 4){
                    store += s + "\n";
                }
                else store = store + line + "\n";
            }
            writer = new FileWriter("SixPots.txt");
            writer.write(store);
            
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (writer != null){
                try {
                    if (reader != null){
                        reader.close();
                    }
                    if (bufferedReader != null){
                        bufferedReader.close();
                    }
                    if (writer != null){
                        writer.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void showMoneyInvestment () {
        try {
            reader = new FileReader("SixPots.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 5){
                    investmentLabel.setText(line);
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (reader != null){
                    reader.close();
                }
                if (bufferedReader != null){
                    bufferedReader.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void saveMoneyInvestment(String s) {
        try {
            reader = new FileReader("SixPots.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            String store = "";
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 5){
                    store += s + "\n";
                }
                else store = store + line + "\n";
            }
            writer = new FileWriter("SixPots.txt");
            writer.write(store);
            
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (writer != null){
                try {
                    if (reader != null){
                        reader.close();
                    }
                    if (bufferedReader != null){
                        bufferedReader.close();
                    }
                    if (writer != null){
                        writer.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void showMoneyCharity () {
        try {
            reader = new FileReader("SixPots.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 6){
                    charityLabel.setText(line);
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (reader != null){
                    reader.close();
                }
                if (bufferedReader != null){
                    bufferedReader.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void saveMoneyCharity(String s) {
        try {
            reader = new FileReader("SixPots.txt");
            bufferedReader = new BufferedReader(reader);
            
            int i = 0;
            String line;
            String store = "";
            while ((line = bufferedReader.readLine()) != null) {
                i++;
                if (i == 6){
                    store += s + "\n";
                }
                else store = store + line + "\n";
            }
            writer = new FileWriter("SixPots.txt");
            writer.write(store);
            
        } catch (Exception ex) {
            Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (writer != null){
                try {
                    if (reader != null){
                        reader.close();
                    }
                    if (bufferedReader != null){
                        bufferedReader.close();
                    }
                    if (writer != null){
                        writer.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ShowInformationsPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void showMainInfo(){
        showMoneyAll();
        showMoneyLeft();
        showMoneyPay();
    }
    
    public void showSixPots(){
        showMoneyNecessary();
        showMoneyEducation();
        showMoneySaving();
        showMoneyEnjoy();
        showMoneyInvestment();
        showMoneyCharity();
    }
   
    public void setTextNecessaryLabel (String s) {
        necessaryLabel.setText(s);
    }
    
    public void setTextEducationLabel (String s) {
        educationLabel.setText(s);
    }
    
    public void setTextSavingLabel (String s) {
        savingLabel.setText(s);
    }
    
    public void setTextEnjoyLabel (String s) {
        enjoyLabel.setText(s);
    }
    
    public void setTextInvestmentLabel (String s) {
        investmentLabel.setText(s);
    }
    
    public void setTextCharityLabel (String s) {
        charityLabel.setText(s);
    }
    
    public String getTextMoneyLeftLabel () {
        return moneyLeftLabel.getText();
    }
    
    public String getTextNecessaryLabel () {
        return necessaryLabel.getText();
    }
    
    public String getTextEducationLabel () {
        return educationLabel.getText();
    }
    
    public String getTextSavingLabel () {
        return savingLabel.getText();
    }
    
    public String getTextEnjoyLabel () {
        return enjoyLabel.getText();
    }
    
    public String getTextInvestmentyLabel () {
        return investmentLabel.getText();
    }
    
    public String getTextCharityLabel () {
        return charityLabel.getText();
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        moneyAllLabel = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        moneyPayLabel = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        moneyLeftLabel = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        educationLabel = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        enjoyLabel = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        necessaryLabel = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        charityLabel = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        savingLabel = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        investmentLabel = new javax.swing.JLabel();

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));

        jPanel2.setBackground(new java.awt.Color(246, 168, 35));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\money-start.png")); // NOI18N
        jLabel5.setText("Số dư ban đầu");

        moneyAllLabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        moneyAllLabel.setForeground(new java.awt.Color(255, 255, 255));
        moneyAllLabel.setText("0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(moneyAllLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(moneyAllLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel4.setBackground(new java.awt.Color(246, 168, 35));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\last_pay.png")); // NOI18N
        jLabel4.setText("Lần chi tiêu cuối");

        moneyPayLabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        moneyPayLabel.setForeground(new java.awt.Color(255, 255, 255));
        moneyPayLabel.setText("0");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(moneyPayLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(moneyPayLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel1.setBackground(new java.awt.Color(246, 168, 35));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\money-left.png")); // NOI18N
        jLabel3.setText("Số dư khả dụng");

        moneyLeftLabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        moneyLeftLabel.setForeground(new java.awt.Color(255, 255, 255));
        moneyLeftLabel.setText("0");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(moneyLeftLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(moneyLeftLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(0, 0, 0));

        jPanel12.setBackground(new java.awt.Color(102, 102, 102));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\education.png")); // NOI18N
        jLabel8.setText("Giáo dục");

        educationLabel.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        educationLabel.setForeground(new java.awt.Color(51, 255, 0));
        educationLabel.setText("0");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
                    .addComponent(educationLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(educationLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel13.setBackground(new java.awt.Color(102, 102, 102));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\enjoy.png")); // NOI18N
        jLabel10.setText("Hưởng thụ");

        enjoyLabel.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        enjoyLabel.setForeground(new java.awt.Color(51, 255, 0));
        enjoyLabel.setText("0");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
                    .addComponent(enjoyLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(enjoyLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(102, 102, 102));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\necessary.png")); // NOI18N
        jLabel1.setText("Thiết yếu");

        necessaryLabel.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        necessaryLabel.setForeground(new java.awt.Color(51, 255, 0));
        necessaryLabel.setText("0");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
                    .addComponent(necessaryLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(necessaryLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel14.setBackground(new java.awt.Color(102, 102, 102));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\charity.png")); // NOI18N
        jLabel12.setText("Thiện nguyện");

        charityLabel.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        charityLabel.setForeground(new java.awt.Color(51, 255, 0));
        charityLabel.setText("0");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
                    .addComponent(charityLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(charityLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel11.setBackground(new java.awt.Color(102, 102, 102));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\saving.png")); // NOI18N
        jLabel6.setText("Tiết kiệm");

        savingLabel.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        savingLabel.setForeground(new java.awt.Color(51, 255, 0));
        savingLabel.setText("0");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
                    .addComponent(savingLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(savingLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel15.setBackground(new java.awt.Color(102, 102, 102));
        jPanel15.setForeground(new java.awt.Color(51, 255, 0));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\Money1\\image\\investment.png")); // NOI18N
        jLabel14.setText("Đầu tư");

        investmentLabel.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        investmentLabel.setForeground(new java.awt.Color(51, 255, 0));
        investmentLabel.setText("0");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
                    .addComponent(investmentLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(investmentLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel charityLabel;
    private javax.swing.JLabel educationLabel;
    private javax.swing.JLabel enjoyLabel;
    private javax.swing.JLabel investmentLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JLabel moneyAllLabel;
    private javax.swing.JLabel moneyLeftLabel;
    private javax.swing.JLabel moneyPayLabel;
    private javax.swing.JLabel necessaryLabel;
    private javax.swing.JLabel savingLabel;
    // End of variables declaration//GEN-END:variables
}
